//--------------------------------------------------------------------------------------------------------------------
// 113_Main.c
//--------------------------------------------------------------------------------------------------------------------

// DEVELOPER :	MURULI
// DATE:	5/02/2014

// Tool chain: KEIL IDE

//--------------------------------------------------------------------------------------------------------------------
// Includes
//--------------------------------------------------------------------------------------------------------------------

//#pragma OR					// order all variables in memory according to their order of definition
//#pragma small				// by default all variables are stored in data memory type

#include<P89V51RD2.H>		// header file of RD2 microcontroller

#include<LCD.c>

#include<113_UART.c>
#include<gsm.c>

//--------------------------------------------------------------------------------------------------------------------
// 16-bit SFR Definitions for "P89V51RD2"
//--------------------------------------------------------------------------------------------------------------------

//--------------------------------------------------------------------------------------------------------------------
// Global VARIABLES
//--------------------------------------------------------------------------------------------------------------------
 

//--------------------------------------------------------------------------------------------------------------------
// Global CONSTANTS
//--------------------------------------------------------------------------------------------------------------------

sbit w_m1=P1^0;
sbit w_m2=P1^1;
sbit w_m11=P1^2;
sbit w_m22=P1^3;
sbit ir1=P3^2;
sbit ir3=P3^4;
sbit ir2=P3^3;
sbit ir4=P3^5;
sbit Relay=P1^4;



code unsigned char SM_clock[] = {0x06,0x0C,0x09,0x03};		// For Clockwise Rotation
code unsigned char SM_anticlock[] = {0x06,0x03,0x09,0x0C};	

char flag=0;

//--------------------------------------------------------------------------------------------------------------------
// Function PROTOTYPES
//--------------------------------------------------------------------------------------------------------------------
void forward_motor();
void reverse_motor();
void left_motor();
void right_motor();
void SM_Clk_Rotate( char SM_data, char step_delay, bit Clk0_Anticlk1_flag );
xdata unsigned char SM_Step_Count = 0;			


void anticlock_Stepper();
void clock_Stepper();
void Device_Init( void );
void MSDelay(unsigned int );
//--------------------------------------------------------------------------------------------------------------------
// void main (void)
//--------------------------------------------------------------------------------------------------------------------

void main( void )
{ 
	 Relay=0; 
  
  

 
  
  
	
	forward_motor();
		
	reverse_motor();
		
left_motor();
	
	right_motor();
		
	
		
	
		

 
	Device_Init( );
   GSM_Init();
	
	
ALCD_Message(  0X80, "  WELCOME  " );
      	MSDelay(500);
       	ALCD_Message(  0X01, "" );

	while(1)
	{
		
				
		

		
	
		
	
	

	
		
		while(Rx_ST_Flag==0)
		{ 
			
			
			
		 if(ir1==1)
		{ 
       ALCD_Message(  0X80, "ENEMY IN FRONT" );
      	MSDelay(1000);
       	ALCD_Message(  0X01, "" );		
   if(flag == 0)
		{
			flag=0;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;

		}
		else if(flag == 1)
		{
			clock_Stepper();
			flag=0;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
				
		}
		else if(flag == 2)
		{
			anticlock_Stepper();
			flag=0;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
			
		}
		else if(flag == 3)
		{
			anticlock_Stepper();
			anticlock_Stepper();
			flag=0;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
			
		} 
		GSM_Send_SMS( Mb_Num, "ENEMY IN FRONT" );
		
		 }
		if(ir2==1)
		{  
			ALCD_Message(  0X80, "ENEMY IN RIGHT" );
      	MSDelay(1000);
       	ALCD_Message(  0X01, "" );
			
			
		if(flag == 0)
		{ 
			

			anticlock_Stepper();
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
	
		}
		else if(flag == 1)
		{
			flag=1;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
				
		}
		else if(flag == 2)
		{
			anticlock_Stepper();
			anticlock_Stepper();
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
		}
		else if(flag == 3)
		{
			clock_Stepper();
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
			
		} 
		GSM_Send_SMS( Mb_Num, "ENEMY IN RIGHT" );
		 }
		if(ir3==1)
		{ 
			
			ALCD_Message(  0X80, "ENEMY IN LEFT" );
      	MSDelay(1000);
       	ALCD_Message(  0X01, "" );
		if(flag == 0)
		{ 
				

			clock_Stepper();
			flag=2;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
			
		}
		else if(flag == 1)
		{
			clock_Stepper();
			clock_Stepper();
			flag=2;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
						

		}
		else if(flag == 2)
		{
			flag=2;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
			
		}
		else if(flag == 3)
		{
			anticlock_Stepper();
			flag=2;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
			

		} 
		GSM_Send_SMS( Mb_Num, "ENEMY IN LEFT" );
		 }
			if(ir4==1)
		{ 
			ALCD_Message(  0X80, "ENEMY IN BEHIND" );
      	MSDelay(1000);
       	ALCD_Message(  0X01, "" );
			
			
		if(flag == 0)
		{ 
				

			clock_Stepper();
		clock_Stepper();
			flag=3;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
		
		}
		else if(flag == 1)
		{
		anticlock_Stepper();
			flag=3;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
					

		}
		else if(flag == 2)
		{
			clock_Stepper();
			flag=3;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
			

		}
		else if(flag == 3)
		{
			flag=3;
			Relay=1;
			MSDelay(300);
			Relay=0;
			MSDelay(300);
			Relay=1;
			MSDelay(300);
			Relay=0;
			
		}	 
		GSM_Send_SMS( Mb_Num, "ENEMY IN BEHIND" );
		
		 }
	
	};
	

			//Rx_ST_Flag=0;
			
		if(Rx_data_arr[1]=='1')
			{  Rx_ST_Flag = 0;
				forward_motor();
			  Rx_count=0;
           Rx_data_arr[0]='9';
			  }
			else if(Rx_data_arr[1]=='4')
			{ 
				Rx_ST_Flag = 0;
				reverse_motor();
				Rx_count=0;
				 Rx_data_arr[0]='9';
			} 
			else if(Rx_data_arr[1]=='3')
			{ 
				Rx_ST_Flag = 0;
				left_motor();
				Rx_count=0;
				 Rx_data_arr[0]='9';
			} 
				else if(Rx_data_arr[1]=='2')
			{ 
				Rx_ST_Flag = 0;
				right_motor();
				Rx_count=0;
				 Rx_data_arr[0]='9';
			}
			
		//	while(1);				
								 		
				
					
			
		

	}
			
	while(1)										// spin over
	{
		;
	}
}



void Device_Init( void )
{
	xdata unsigned char UC_count = 0xFD;	// For 9600 Buad Rate

	EA = 0;
	
	//Buzzer=0;
	
	


	UART0M1_Tx_Init( );
	// UART0 mode 1 Transmit initialization					
	Timer1M2_Init( UC_count );				// Timer 1 mode 2 initializatio						// Enable Global Interrupts
	TR1 = 1;								// Start Timer 1
 ALCD_Init();
	


										// 0.1 sec delay
	

}
void MSDelay( unsigned int Milli_Sec )
{
	data unsigned int x,y;

	for(x=0;x<Milli_Sec;x++)
	{
		for(y=0;y<180;y++)
		{
		
		}
	}
}
void forward_motor()
{
	
	w_m1=1;
  w_m2=0;
  w_m11=1;
	w_m22=0;
	
	MSDelay( 1000);
	
		w_m1=0;
    w_m2=0;
    w_m11=0;
	  w_m22=0;
}
void reverse_motor()
{ 
	w_m1=0;
  w_m2=1;
  w_m11=0;
	w_m22=1;
	
	MSDelay( 1000);
	
		w_m1=0;
    w_m2=0;
    w_m11=0;
	  w_m22=0;
} 
void left_motor()
{
	w_m1=1;
  w_m2=0;
  w_m11=0;
	w_m22=1;
	
	MSDelay( 1000);
	
		w_m1=0;
    w_m2=0;
    w_m11=0;
	  w_m22=0;
} 
void right_motor()
{
	w_m1=0;
  w_m2=1;
  w_m11=1;
	w_m22=0;
	
	MSDelay( 1000);
	
		w_m1=0;
    w_m2=0;
    w_m11=0;
	  w_m22=0;
} 

void clock_Stepper()
{  
	unsigned char i;
	SM_Step_Count = 0;
	
	for( i=0; i<50; i++ )
	{
		SM_Clk_Rotate( SM_Step_Count, 5, 0 );		// Clock wise rotation
		SM_Step_Count++;
		if( SM_Step_Count > 3 )
			SM_Step_Count = 0;
	} 	
}
void anticlock_Stepper()
{ 
	
		unsigned char i;
	SM_Step_Count = 0;
	for( i=0; i<50; i++ ) 
	{
		SM_Clk_Rotate( SM_Step_Count, 5, 1 );		// Anti clock wise rotation
		SM_Step_Count++;
		if( SM_Step_Count > 3 )
			SM_Step_Count = 0;
	}
}

	void SM_Clk_Rotate( char SM_data, char step_delay, bit Clk0_Anticlk1_flag )
{

	if ( Clk0_Anticlk1_flag == 0 )
		
	
	else if ( Clk0_Anticlk1_flag == 1 )
		
	
	
	MSDelay( step_delay );

}
	
	
	
	
	
	
	
	
	