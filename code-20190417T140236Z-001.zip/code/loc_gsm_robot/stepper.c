
//---------------------------------------------------------------------------------------------
xdata unsigned char SM_Step_Count = 0;			

//--------------------------------------------------------------------------------------------------------------------
// Global CONSTANTS
//--------------------------------------------------------------------------------------------------------------------

code unsigned char SM_clock[] = {0x06,0x0C,0x09,0x03};		// For Clockwise Rotation
code unsigned char SM_anticlock[] = {0x06,0x03,0x09,0x0C};	// For Anti-clockwise Rotation

//--------------------------------------------------------------------------------------------------------------------
// Function PROTOTYPES
//--------------------------------------------------------------------------------------------------------------------


void SM_Clk_Rotate( char SM_data, char step_delay, bit Clk0_Anticlk1_flag );

//--------------------------------------------------------------------------------------------------------------------






void SM_Clk_Rotate( char SM_data, char step_delay, bit Clk0_Anticlk1_flag )
{

	if ( Clk0_Anticlk1_flag == 0 )
		P1 = SM_clock[SM_data];
	
	else if ( Clk0_Anticlk1_flag == 1 )
		P1 = SM_anticlock[SM_data];
	
	
	MSDelay( step_delay );

}

